<?php

namespace upup;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\level\Position;
use pocketmine\Player;
use pocketmine\block\Block;
use pocketmine\math\Vector3;

class upup extends PluginBase implements Listener {
	public function onEnable() {
		$this->getServer ()->getPluginManager ()->registerEvents ( $this, $this );
	}
	public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
	$command = $command->getName ();
	$player = $sender->getPlayer ();
	$name = $sender->getName ();
	$y = $player->getY();
$t = ("§6§l[§f§l UP§6§l ]§f ");
	if ($command == "up"){
	if( ! isset($args[0]) ){
	$sender->sendMessage($t."/up <숫자> 올라간다음 아레 유리블럭을 생성합니다.");
	return true;
	}
	if ( !$sender->isOP()){
	$sender->sendMessage($t."관리자 명령어 입니다.");
	return true;
}
if(!is_numeric($args[0])){
	$player->sendMessage($t."숫자을 써주세요.");
return true;
}
$mmm = intval($player->y);
		if(($mmm + $args[0]) > 256){
	$player->sendMessage($t."256 이상 더 높이 올라갈수 없습니다.");
	return true;
	}
		if($args[0] < 0){
	$player->sendMessage($t."0이상 써주세요.");
	return true;
	}
	$message = implode(" ", $args);
	$y = $player->getY();
	$player->teleport(new 
Position(floatval($player->x), floatval($player->y) + 
$message, floatval($player->z), $player->getLevel()));
$player->getLevel()->setBlock(new Vector3($player->getX(), $player->getY() -1,
$player->getZ()), Block::get(20));
$player->sendMessage($t."{$message}만큼 올라갔습니다.");
return true;
}
return true;
}
}